import wiringpi

SW = 4
LED1 = 27
INPUT = 0
OUTPUT = 1

wiringpi.wiringPiSetup()

wiringpi.pinMode(SW, INPUT)
wiringpi.pinMode(LED1, OUTPUT)

while True:
	wiringpi.digitalWrite(LED1, 0) 
	if wiringpi.digitalRead(SW) == 0:
		wiringpi.digitalWrite(LED1, 1) 
		wiringpi.delay(1000)  
