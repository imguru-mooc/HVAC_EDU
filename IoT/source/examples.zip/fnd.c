#include <stdio.h>
#include <wiringPi.h>

#define	SEG_DIG	 1
#define	LED	0

int led[] = { 11,10,13,12,14,15,16,0 };
int num[10][8] = { 
	{ 0, 0, 0, 0, 0, 0, 1, 1 },
	{ 1, 0, 0, 1, 1, 1, 1, 1 },
	{ 0, 0, 1, 0, 0, 1, 0, 1 },
	{ 0, 0, 0, 0, 1, 1, 0, 1 },
	{ 1, 0, 0, 1, 1, 0, 0, 1 },
	{ 0, 1, 0, 0, 1, 0, 0, 1 },
	{ 0, 1, 0, 0, 0, 0, 0, 1 },
	{ 0, 0, 0, 1, 1, 1, 1, 1 },
	{ 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 0, 0, 0, 0, 1, 0, 0, 1 }
};

void fnd_write( int row )
{
	int i,j,k;
	int pin=0;
	int n;
	for(k=0; k<60; k++ )
	{
		n = row;
		for(i=0; i<3; i++ )
		{
			n = row%10;
			for( j=0; j<3; j++ )
				digitalWrite( SEG_DIG+j, (2-i)==j );

			for( j=0, pin=0; j<8; j++, pin++ )
				digitalWrite (led[pin], !num[n][j] );	

			delay(2);

			n /= 10;
			if( n == 0 ) 
				break;
		}
		//delay(10);
	}
}

int main (void)
{
	int i;
	wiringPiSetup () ;
	for(i=0; i<3; i++ )
		pinMode (SEG_DIG+i, OUTPUT) ;

	for(i=0; i<7; i++ )
		pinMode (led[i], OUTPUT) ;

	for (i=0;i<1000;i++)
	{
		fnd_write( i );
		delay (500) ;
	}
	return 0 ;
}
