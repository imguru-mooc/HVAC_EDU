#include <stdio.h>

int main()
{
	int ip = 0x12345678;
	int i;

	char *p = (char*)&ip;

	ip = ((ip&0xff000000)>>24)|
		  ((ip&0xff0000)>>8)|
		  ((ip&0xff00)<<8)|
		  ((ip&0xff)<<24);


	for(i=0; i<4; i++)
		printf("%x\n", p[i] );
	return 0;
}
