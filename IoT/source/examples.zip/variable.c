
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include <wiringPi.h>
#include <mcp3422.h>

int main (int argc, char *argv [])
{
	wiringPiSetup () ;
	mcp3422Setup (400, 0x6a, 0, 0) ;

	for (;;)
	{
		int reading = analogRead(403);  // 센서로 부터 자료값을 받는다.
		double voltage = (reading*5)/1024.;
		printf ("%5.2lf\n",   voltage);
		printf ("%d\n",   reading);
		delay (1000) ;
	}

}
