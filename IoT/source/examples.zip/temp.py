import wiringpi

wiringpi.wiringPiSetup () 
wiringpi.mcp3422Setup (400, 0x6a, 0, 0) 

while True:
	reading = wiringpi.analogRead(401)  
# print(type(reading))
# print("%d"%reading)
	voltage = (reading*5)/1024.
	celsiustemp = (voltage-2.7)*(165/2.8) - 40
	print("%5.2f"%voltage)
	print("%5.2f"%celsiustemp)
	wiringpi.delay (1000)
