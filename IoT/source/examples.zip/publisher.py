import random
import time
import paho.mqtt.client as mqtt_client


broker_address = "localhost"
broker_port = 1883

topic = "input/button"


def connect_mqtt() :
    def on_connect(client, userdata, flags, rc):
	    if rc == 0:
	        print("Connected to MQTT Broker")
	    else:
	        print("Failed to connect")

    def on_disconnect(client, userdata, flags, rc=0):
		print("disconnected result code")

    def on_log(client, userdata, level, buf):
		print("log: ")

    client_id = "mqtt_client_{}".format(random.randint(0, 1000))
    client = mqtt_client.Client(client_id)

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_log = on_log

    client.connect(host=broker_address, port=broker_port)
    return client


def publish(client):
    msg_count = 0
    while True:
        time.sleep(1)
        msg = "messages: {}".format(msg_count)
        result = client.publish(topic, msg)
        status = result[0]
        if status == 0:
            print("Send {} to topic {}".format(msg, topic))
        else:
            print("Failed to send message to topic {}".format(topic))
        msg_count += 1


def run():
    client = connect_mqtt()
    client.loop_start() #5
    print("connect to broker {}:{}".format(broker_address,broker_port))
    publish(client) #6

if __name__ == '__main__':
    run()

Client(client_id='', clean_session=True, userdata=None, protocol=MQTTv311, transport='tcp')
