import wiringpi

OUTPUT = 1
HIGH = 1
LOW = 0
leds = [27,24,28,29]


def led_on( ratio ):
	limit = ratio / 512 
	for i in range(4):
		if i<=limit:
		    wiringpi.digitalWrite( leds[i], HIGH )
		else:
			wiringpi.digitalWrite( leds[i], LOW )

wiringpi.wiringPiSetup () 
wiringpi.mcp3422Setup (400, 0x6a, 0, 0) 

for i in range(4):
	wiringpi.pinMode( leds[i], OUTPUT )
	wiringpi.digitalWrite( leds[i], LOW )

while True:
	reading = wiringpi.analogRead(403);
	print("%d"%reading)
	led_on( reading )
	wiringpi.delay (1000) 
